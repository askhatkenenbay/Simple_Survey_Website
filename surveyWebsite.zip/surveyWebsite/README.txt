You can find print screens in folder print_screen

You can find queries to create database in file createDB.txt

Java EE 11, Apache Tomcat, Javascript, HTML, CSS, MySQL, Maven, MVC

Design patterns used: proxy, factory, pool, singleton

External libraries: mysql-connector-java and javax.servlet

Example of user: 
	name: Admin
	email: Admin@gmail.com
	password: Admin123#

Validity of input checked in frontend and backend

github: https://github.com/askhatkenenbay/Simple_Survey_Website
//some files in github version were deleted because of limitation
