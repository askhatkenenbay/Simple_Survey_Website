function submitSurvey() {
    document.getElementById("survey-form").submit();
}